// 类型定义于 @/types/glabal.d.ts中
// eslint-disable-next-line no-unused-vars
const globalConfig = {
  title: '公共项目'
}
