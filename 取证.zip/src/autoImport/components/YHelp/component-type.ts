export interface YHelpProps {
  /* 说明文字 */
  message?: string | string[]
  /* 图标 */
  icon?: string
  /* 图标大小 */
  size?: string
  /* 图标颜色 */
  color?: string
}
