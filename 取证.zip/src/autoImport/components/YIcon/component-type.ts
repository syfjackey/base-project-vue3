export interface YIconProps {
  /* 图标 */
  icon?: string
  /* 图标大小 */
  size?: string
  /* 图标颜色 */
  color?: string
}
