export interface YBarProps {
  /* 方向 */
  dir?: 'row' | 'column'
  /* 间隔 */
  gap?: string
}
