<script setup lang="ts"></script>
<template>
  <div class="home__container"></div>
</template>
<style lang="scss" scoped>
.home__container {
  @apply box-fit overflow-hidden box-border;
  overflow: auto;
  background: #f3f3f5;
  padding: 10px;
  display: flex;
  flex-direction: column;
}
</style>
