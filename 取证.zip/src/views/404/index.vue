<script setup lang="ts"></script>
<template>
  <div class="notfound__container">无法找到该页面</div>
</template>
<style lang="scss" scoped>
.notfound__container {
  width: 100%;
  height: 100%;
}
</style>
